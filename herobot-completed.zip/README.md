# HeroBot 26.2 — AI Companion Bot (Minecraft Java 26.2, Fabric)

HeroBot spawns a controllable, player-like AI companion that follows, fights, protects,
and survives alongside its owner. Built for **Minecraft Java Edition 26.2** on **Fabric**.

## Verified environment (grounded against Fabric/Mojang metadata, Nov 2026)
- **Minecraft:** 26.2 (protocol 776, data 4903) — requires **Java 25**
- **Fabric Loader:** 0.20.1
- **Fabric API:** 0.159.0+26.2
- **Loom:** 1.19.4 · **Gradle:** 9.8.2
- **Mappings:** official Mojang mappings (Yarn is not published for calendar versions;
  Loom 1.19 applies Mojang mappings by default). Note: `ResourceLocation` is named
  `net.minecraft.resources.Identifier` in 26.2.

## Build
```bash
export JAVA_HOME=/path/to/jdk-25
./gradlew build
```
The mod JAR is produced at `build/libs/herobot-26.2.0.jar`.

## Install
1. Install the Fabric Loader (0.20.1+) for Minecraft 26.2.
2. Put **Fabric API** (0.159.0+26.2) and **herobot-26.2.0.jar** in your `mods/` folder.
3. Launch with the Java 25 runtime bundled by the official launcher.

## Commands
`/herobot spawn | remove | follow | stay | come | attack | defend | protect |
mine <block> | collect | inventory | equip | retrieve | status | teleport | help`

| Mode | Behaviour |
|---|---|
| follow / come | Stays with you; retaliates against attackers; auto-picks up nearby drops (config) |
| stay | Holds position (sits) |
| attack | Hunts any hostile mob within its follow range |
| defend | Only fights what hurts you or it |
| protect | Engages hostiles that come within 12 blocks of you |
| mine `<block>` | Finds the nearest matching block (~10 blocks), walks over, breaks it |
| collect | Gathers dropped items within 16 blocks into its 27-slot backpack |

**Interaction:** right-click the bot holding an item to give it (better armour/swords/shields are
equipped automatically, food is eaten when hurt, everything else goes in the backpack).
Sneak + empty hand toggles stay/follow. `/herobot retrieve` hands the backpack back to you.
The backpack, mode and mine target persist across saves; the backpack drops on death.

## Architecture
`herobot` (init) · `herobot.entity` · `herobot.ai` · `herobot.navigation` ·
`herobot.combat` · `herobot.commands` · `herobot.inventory` · `herobot.config` ·
`herobot.network` · `herobot.mixin` · `herobot.client`

The bot extends `TamableAnimal`, giving it owner tracking, sitting, and vanilla
owner-teleport recovery. Vanilla AI `Goal`s provide robust A* ground navigation,
obstacle avoidance and stair climbing; combat, survival and behaviour-mode logic are
layered on top. A `Mob` mixin lets hostile mobs recognise the bot as a target.

## Build/compile status
The original skeleton was reported to build against 26.2. The features added afterwards (mine /
collect / inventory / mode-aware combat / persistence / interaction / texture & icon) were written
**without access to the Minecraft toolchain and have not been compiled or play-tested**. If
`./gradlew build` reports an unresolved symbol, it will most likely be a Mojang-mapping name that
shifted in 26.x (see "Likely compile snags" in the hand-off notes).

`gradle/wrapper/gradle-wrapper.jar` was missing from the upload; regenerate it with
`gradle wrapper --gradle-version 9.8.2` (needs a local Gradle) before using `./gradlew`.

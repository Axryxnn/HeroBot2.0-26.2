package com.herobot.ai;

import com.herobot.entity.HeroBotEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;

/**
 * In MINE mode: finds the nearest block of the configured type, walks to it and breaks it.
 * Drops spawn in the world and are then picked up by {@link CollectItemsGoal}.
 */
public class MineBlockGoal extends Goal {
	private static final int SEARCH_RADIUS = 10;
	private static final int BREAK_TICKS = 25;

	private final HeroBotEntity bot;
	private BlockPos targetPos;
	private int breakProgress;
	private int repath;
	private int searchCooldown;

	public MineBlockGoal(HeroBotEntity bot) {
		this.bot = bot;
		setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
	}

	@Override
	public boolean canUse() {
		if (bot.getBehaviorMode() != BehaviorMode.MINE || bot.getMineTarget() == null
				|| bot.getTarget() != null || bot.isOrderedToSit()) {
			return false;
		}
		if (--searchCooldown > 0) {
			return false;
		}
		searchCooldown = 20;
		targetPos = findNearest();
		return targetPos != null;
	}

	@Override
	public boolean canContinueToUse() {
		return targetPos != null && bot.getBehaviorMode() == BehaviorMode.MINE
				&& bot.getTarget() == null && matches(targetPos);
	}

	@Override
	public void start() {
		breakProgress = 0;
		repath = 0;
	}

	@Override
	public void stop() {
		targetPos = null;
		breakProgress = 0;
		bot.getNavigation().stop();
	}

	private boolean matches(BlockPos pos) {
		Block wanted = bot.getMineTarget();
		return wanted != null && bot.level().getBlockState(pos).is(wanted);
	}

	private BlockPos findNearest() {
		BlockPos origin = bot.blockPosition();
		BlockPos best = null;
		double bestDist = Double.MAX_VALUE;
		for (BlockPos pos : BlockPos.betweenClosed(
				origin.offset(-SEARCH_RADIUS, -4, -SEARCH_RADIUS),
				origin.offset(SEARCH_RADIUS, 4, SEARCH_RADIUS))) {
			if (matches(pos)) {
				double d = pos.distSqr(origin);
				if (d < bestDist) {
					bestDist = d;
					best = pos.immutable();
				}
			}
		}
		return best;
	}

	@Override
	public void tick() {
		if (targetPos == null || !(bot.level() instanceof ServerLevel level)) {
			return;
		}
		bot.getLookControl().setLookAt(targetPos.getX() + 0.5D, targetPos.getY() + 0.5D, targetPos.getZ() + 0.5D);
		double distSq = bot.distanceToSqr(targetPos.getX() + 0.5D, targetPos.getY() + 0.5D, targetPos.getZ() + 0.5D);
		if (distSq > 6.25D) {
			breakProgress = 0;
			if (--repath <= 0) {
				repath = 10;
				bot.getNavigation().moveTo(targetPos.getX() + 0.5D, targetPos.getY(), targetPos.getZ() + 0.5D, 1.1D);
			}
			return;
		}
		bot.getNavigation().stop();
		if (breakProgress % 5 == 0) {
			bot.swing(net.minecraft.world.InteractionHand.MAIN_HAND);
		}
		if (++breakProgress >= BREAK_TICKS) {
			BlockState state = level.getBlockState(targetPos);
			if (!state.isAir() && state.getDestroySpeed(level, targetPos) >= 0.0F) {
				level.destroyBlock(targetPos, true, bot);
			}
			targetPos = null;
			breakProgress = 0;
		}
	}
}

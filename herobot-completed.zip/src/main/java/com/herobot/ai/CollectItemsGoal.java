package com.herobot.ai;

import com.herobot.config.ConfigManager;
import com.herobot.entity.HeroBotEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/**
 * Walks to dropped items and stores them in the bot's inventory. Always active in COLLECT mode;
 * in FOLLOW/MINE modes it only runs when {@code autoCollectItems} is enabled (small radius).
 */
public class CollectItemsGoal extends Goal {
	private final HeroBotEntity bot;
	private ItemEntity targetItem;
	private int repath;

	public CollectItemsGoal(HeroBotEntity bot) {
		this.bot = bot;
		setFlags(EnumSet.of(Flag.MOVE));
	}

	private double radius() {
		BehaviorMode mode = bot.getBehaviorMode();
		if (mode == BehaviorMode.COLLECT) {
			return 16.0D;
		}
		if ((mode == BehaviorMode.FOLLOW || mode == BehaviorMode.MINE) && ConfigManager.get().autoCollectItems) {
			return 6.0D;
		}
		return 0.0D;
	}

	@Override
	public boolean canUse() {
		double r = radius();
		if (r <= 0.0D || bot.getTarget() != null || bot.isOrderedToSit()) {
			return false;
		}
		AABB box = bot.getBoundingBox().inflate(r);
		List<ItemEntity> items = bot.level().getEntitiesOfClass(ItemEntity.class, box,
				e -> e.isAlive() && !e.hasPickUpDelay() && bot.getInventory().canAddItem(e.getItem()));
		this.targetItem = items.stream()
				.min(Comparator.comparingDouble(bot::distanceToSqr)).orElse(null);
		return this.targetItem != null;
	}

	@Override
	public boolean canContinueToUse() {
		return targetItem != null && targetItem.isAlive() && bot.getTarget() == null && !bot.isOrderedToSit();
	}

	@Override
	public void stop() {
		targetItem = null;
		bot.getNavigation().stop();
	}

	@Override
	public void tick() {
		if (targetItem == null) {
			return;
		}
		if (bot.distanceToSqr(targetItem) <= 2.25D) {
			ItemStack remainder = bot.getInventory().addItem(targetItem.getItem().copy());
			if (remainder.isEmpty()) {
				targetItem.discard();
			} else {
				targetItem.setItem(remainder);
			}
			targetItem = null;
			return;
		}
		if (--repath <= 0) {
			repath = 10;
			bot.getNavigation().moveTo(targetItem, 1.2D);
		}
	}
}

package com.herobot.ai;

import com.herobot.entity.HeroBotEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;

/**
 * Proactive hostile-mob targeting that respects the bot's {@link BehaviorMode}.
 * ATTACK engages any hostile in range, PROTECT only hostiles near the owner,
 * every other mode never goes hunting (retaliation goals still apply).
 */
public class ModeTargetGoal extends NearestAttackableTargetGoal<Monster> {
	private final HeroBotEntity bot;

	public ModeTargetGoal(HeroBotEntity bot) {
		super(bot, Monster.class, true);
		this.bot = bot;
	}

	@Override
	public boolean canUse() {
		BehaviorMode mode = bot.getBehaviorMode();
		if (mode != BehaviorMode.ATTACK && mode != BehaviorMode.PROTECT) {
			return false;
		}
		if (!super.canUse() || this.target == null) {
			return false;
		}
		if (mode == BehaviorMode.PROTECT) {
			LivingEntity owner = bot.getOwner();
			return owner != null && this.target.distanceToSqr(owner) <= 12.0D * 12.0D;
		}
		return true;
	}
}

package com.herobot;

import com.herobot.commands.HeroBotCommands;
import com.herobot.config.ConfigManager;
import com.herobot.entity.HeroBotEntities;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common entrypoint for the HeroBot mod (runs on both the client and the dedicated server).
 *
 * <p>Boots up configuration, registers the bot entity + its attributes, and wires the
 * {@code /herobot} command tree into the server command dispatcher.</p>
 */
public class HeroBot implements ModInitializer {
	public static final String MOD_ID = "herobot";
	public static final Logger LOGGER = LoggerFactory.getLogger("HeroBot");

	@Override
	public void onInitialize() {
		LOGGER.info("[HeroBot] Initializing for Minecraft 26.2 (Fabric)");
		ConfigManager.load();
		HeroBotEntities.register();
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				HeroBotCommands.register(dispatcher));
		LOGGER.info("[HeroBot] Initialization complete");
	}
}

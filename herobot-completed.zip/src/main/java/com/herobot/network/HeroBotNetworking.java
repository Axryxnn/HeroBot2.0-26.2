package com.herobot.network;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Lightweight server-&gt;owner messaging layer. The bot's live state (behaviour mode, sitting flag,
 * health) is already replicated to clients through the entity's synched data, so dedicated custom
 * packets are not required; this helper centralises owner notifications sent over the network.
 */
public final class HeroBotNetworking {
	private HeroBotNetworking() {
	}

	public static void notifyOwner(ServerPlayer owner, String message) {
		if (owner != null) {
			owner.sendSystemMessage(Component.literal("\u00A7b[HeroBot] \u00A7f" + message));
		}
	}
}

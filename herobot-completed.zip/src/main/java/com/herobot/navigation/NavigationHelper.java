package com.herobot.navigation;

import com.herobot.entity.HeroBotEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.navigation.PathNavigation;

/**
 * Navigation utilities layered on top of vanilla's A* ground navigation: owner retreat and a
 * stuck-detection rescue so the bot never pins itself permanently against a wall.
 */
public final class NavigationHelper {
	private NavigationHelper() {
	}

	/** Walk the bot back toward its owner (used when fleeing at low health). */
	public static void retreatToOwner(HeroBotEntity bot) {
		LivingEntity owner = bot.getOwner();
		if (owner == null) {
			return;
		}
		PathNavigation nav = bot.getNavigation();
		if (!nav.moveTo(owner.getX(), owner.getY(), owner.getZ(), 1.3D)) {
			// Path blocked -> fall back to the built-in owner teleport helper.
			bot.tryToTeleportToOwner();
		}
	}

	/**
	 * If the bot has an owner, is far away and its navigation has given up (no path), use the
	 * vanilla owner-teleport to recover instead of grinding against an obstacle forever.
	 */
	public static void rescueIfStuck(HeroBotEntity bot) {
		LivingEntity owner = bot.getOwner();
		if (owner == null || bot.isOrderedToSit()) {
			return;
		}
		double distSq = bot.distanceToSqr(owner);
		if (distSq > 20.0D * 20.0D && bot.getNavigation().isDone()) {
			if (bot.shouldTryTeleportToOwner()) {
				bot.tryToTeleportToOwner();
			}
		}
	}
}

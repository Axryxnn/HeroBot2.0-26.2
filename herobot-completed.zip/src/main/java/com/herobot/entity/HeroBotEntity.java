package com.herobot.entity;

import com.herobot.ai.BehaviorMode;
import com.herobot.ai.CollectItemsGoal;
import com.herobot.ai.MineBlockGoal;
import com.herobot.ai.ModeTargetGoal;
import com.herobot.combat.CombatManager;
import com.herobot.config.ConfigManager;
import com.herobot.config.HeroBotConfig;
import com.herobot.inventory.EquipmentManager;
import com.herobot.navigation.NavigationHelper;
import com.mojang.serialization.Codec;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

/**
 * The HeroBot companion entity. Built on top of {@link TamableAnimal} so it inherits owner tracking,
 * sitting, and the vanilla "teleport to owner" helpers, while vanilla AI {@code Goal}s provide the
 * robust A*-based ground navigation, obstacle avoidance and stair climbing. Combat, survival and
 * behaviour-mode logic are layered on top.
 */
public class HeroBotEntity extends TamableAnimal implements RangedAttackMob {
	private static final EntityDataAccessor<Byte> DATA_MODE =
			SynchedEntityData.defineId(HeroBotEntity.class, EntityDataSerializers.BYTE);

	public static final int INVENTORY_SIZE = 27;

	@Nullable
	private Vec3 stayAnchor;
	private int tickCounter;
	private final SimpleContainer inventory = new SimpleContainer(INVENTORY_SIZE);
	@Nullable
	private Block mineTarget;

	public HeroBotEntity(EntityType<? extends TamableAnimal> type, Level level) {
		super(type, level);
		setPersistenceRequired();
		setCanPickUpLoot(true);
	}

	public static AttributeSupplier.Builder createAttributes() {
		HeroBotConfig cfg = ConfigManager.get();
		return TamableAnimal.createMobAttributes()
				.add(Attributes.MAX_HEALTH, cfg.maxHealth)
				.add(Attributes.MOVEMENT_SPEED, cfg.movementSpeed)
				.add(Attributes.ATTACK_DAMAGE, cfg.attackDamage)
				.add(Attributes.ATTACK_KNOCKBACK, 1.0D)
				.add(Attributes.FOLLOW_RANGE, 16.0D + 8.0D * Math.max(1, Math.min(3, cfg.aiDifficulty)))
				.add(Attributes.ARMOR, 6.0D)
				.add(Attributes.STEP_HEIGHT, 1.0D);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_MODE, BehaviorMode.FOLLOW.toByte());
	}

	@Override
	protected void registerGoals() {
		HeroBotConfig cfg = ConfigManager.get();
		goalSelector.addGoal(0, new FloatGoal(this));
		goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
		goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2D, true));
		goalSelector.addGoal(3, new MineBlockGoal(this));
		goalSelector.addGoal(4, new FollowOwnerGoal(this,
				1.1D, (float) cfg.followStartDistance, (float) cfg.followStopDistance));
		goalSelector.addGoal(5, new CollectItemsGoal(this));
		goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.9D));
		goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
		goalSelector.addGoal(8, new RandomLookAroundGoal(this));

		targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
		targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
		targetSelector.addGoal(3, new HurtByTargetGoal(this));
		targetSelector.addGoal(4, new ModeTargetGoal(this));
	}

	// ---- behaviour mode ----

	public BehaviorMode getBehaviorMode() {
		return BehaviorMode.fromByte(this.entityData.get(DATA_MODE));
	}

	public void setBehaviorMode(BehaviorMode mode) {
		this.entityData.set(DATA_MODE, mode.toByte());
		switch (mode) {
			case STAY -> {
				setOrderedToSit(true);
				this.stayAnchor = position();
				getNavigation().stop();
			}
			case FOLLOW, COME -> {
				setOrderedToSit(false);
				this.stayAnchor = null;
			}
			default -> setOrderedToSit(false);
		}
	}

	/** Resolves "diamond_ore" or "minecraft:diamond_ore" to a block; null if unknown or air. */
	@Nullable
	public static Block lookupBlock(String id) {
		Identifier parsed = Identifier.tryParse(id.contains(":") ? id : "minecraft:" + id);
		if (parsed == null) {
			return null;
		}
		Block block = BuiltInRegistries.BLOCK.getValue(parsed);
		return block == Blocks.AIR ? null : block;
	}

	public SimpleContainer getInventory() {
		return inventory;
	}

	@Nullable
	public Block getMineTarget() {
		return mineTarget;
	}

	public void setMineTarget(@Nullable Block block) {
		this.mineTarget = block;
	}

	// ---- persistence ----

	@Override
	public void addAdditionalSaveData(ValueOutput output) {
		super.addAdditionalSaveData(output);
		output.putInt("HeroBotMode", getBehaviorMode().ordinal());
		List<ItemStack> items = new ArrayList<>(INVENTORY_SIZE);
		for (int i = 0; i < inventory.getContainerSize(); i++) {
			items.add(inventory.getItem(i));
		}
		output.store("HeroBotInventory", Codec.list(ItemStack.OPTIONAL_CODEC), items);
		if (mineTarget != null) {
			output.putString("HeroBotMineTarget", BuiltInRegistries.BLOCK.getKey(mineTarget).toString());
		}
	}

	@Override
	public void readAdditionalSaveData(ValueInput input) {
		super.readAdditionalSaveData(input);
		BehaviorMode mode = BehaviorMode.fromByte((byte) input.getIntOr("HeroBotMode", 0));
		this.entityData.set(DATA_MODE, mode.toByte());
		if (mode == BehaviorMode.STAY) {
			this.stayAnchor = position();
		}
		input.read("HeroBotInventory", Codec.list(ItemStack.OPTIONAL_CODEC)).ifPresent(items -> {
			for (int i = 0; i < items.size() && i < inventory.getContainerSize(); i++) {
				inventory.setItem(i, items.get(i));
			}
		});
		String id = input.getStringOr("HeroBotMineTarget", "");
		this.mineTarget = id.isEmpty() ? null : lookupBlock(id);
	}

	@Override
	protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
		super.dropCustomDeathLoot(level, source, recentlyHit);
		for (int i = 0; i < inventory.getContainerSize(); i++) {
			ItemStack stack = inventory.removeItemNoUpdate(i);
			if (!stack.isEmpty()) {
				spawnAtLocation(level, stack);
			}
		}
	}

	// ---- owner interaction: hand items over, or sneak + empty hand to toggle stay/follow ----

	@Override
	public InteractionResult mobInteract(Player player, InteractionHand hand) {
		if (!isOwnedBy(player)) {
			return InteractionResult.PASS;
		}
		if (!(level() instanceof ServerLevel)) {
			return InteractionResult.SUCCESS;
		}
		ItemStack held = player.getItemInHand(hand);
		if (held.isEmpty()) {
			if (player.isShiftKeyDown()) {
				boolean nowStay = getBehaviorMode() != BehaviorMode.STAY;
				setBehaviorMode(nowStay ? BehaviorMode.STAY : BehaviorMode.FOLLOW);
				if (player instanceof ServerPlayer sp) {
					com.herobot.network.HeroBotNetworking.notifyOwner(sp,
							nowStay ? "HeroBot is staying here." : "HeroBot is following you.");
				}
				return InteractionResult.SUCCESS;
			}
			return InteractionResult.PASS;
		}
		ItemStack rest = EquipmentManager.acceptItem(this, held.copy());
		if (rest.getCount() == held.getCount()) {
			return InteractionResult.PASS; // inventory full
		}
		if (!player.getAbilities().instabuild) {
			held.setCount(rest.getCount());
		}
		return InteractionResult.SUCCESS;
	}

	// ---- per-tick survival / combat upkeep ----

	@Override
	public void customServerAiStep(ServerLevel level) {
		super.customServerAiStep(level);
		tickCounter++;
		if (tickCounter % 20 != 0) {
			return;
		}
		HeroBotConfig cfg = ConfigManager.get();
		float healthFraction = getHealth() / getMaxHealth();

		// Retreat & stop fighting when badly hurt.
		if (healthFraction <= cfg.retreatHealthFraction && getTarget() != null) {
			setTarget(null);
			NavigationHelper.retreatToOwner(this);
		}

		// Eat held food when hurt.
		if (healthFraction <= cfg.eatHealthFraction) {
			EquipmentManager.tryEatFood(this);
		}

		// Wear/wield the best gear from the inventory, then guarantee a weapon + shield.
		EquipmentManager.equipBest(this);
		CombatManager.selectEquipment(this);

		// Keep "stay" bots anchored and rescue stuck bots.
		if (getBehaviorMode() == BehaviorMode.STAY && stayAnchor != null) {
			if (position().distanceToSqr(stayAnchor) > 9.0D) {
				getNavigation().moveTo(stayAnchor.x, stayAnchor.y, stayAnchor.z, 1.0D);
			}
		} else {
			NavigationHelper.rescueIfStuck(this);
		}
	}

	@Override
	public void performRangedAttack(LivingEntity target, float power) {
		CombatManager.performRangedAttack(this, target, power);
	}

	@Override
	public boolean isFood(net.minecraft.world.item.ItemStack stack) {
		return false;
	}

	@Nullable
	@Override
	public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
		return null; // HeroBots are summoned, never bred.
	}

	@Override
	public boolean canBeLeashed() {
		return true;
	}

	public Component ownerName() {
		LivingEntity owner = getOwner();
		return owner != null ? owner.getName() : Component.literal("<none>");
	}
}

package com.herobot.entity;

import com.herobot.HeroBot;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

/**
 * Registry holder for the HeroBot entity type and its default attributes.
 */
public final class HeroBotEntities {
	public static final Identifier HEROBOT_ID = Identifier.fromNamespaceAndPath(HeroBot.MOD_ID, "herobot");
	public static final ResourceKey<EntityType<?>> HEROBOT_KEY = ResourceKey.create(Registries.ENTITY_TYPE, HEROBOT_ID);

	public static final EntityType<HeroBotEntity> HEROBOT = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			HEROBOT_KEY,
			EntityType.Builder.of(HeroBotEntity::new, MobCategory.CREATURE)
					.sized(0.6F, 1.8F)
					.eyeHeight(1.62F)
					.clientTrackingRange(10)
					.build(HEROBOT_KEY));

	private HeroBotEntities() {
	}

	public static void register() {
		FabricDefaultAttributeRegistry.register(HEROBOT, HeroBotEntity.createAttributes());
		HeroBot.LOGGER.info("[HeroBot] Registered entity type {}", HEROBOT_ID);
	}
}

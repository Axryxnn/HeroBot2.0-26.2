package com.herobot.inventory;

import com.herobot.entity.HeroBotEntity;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemAttributeModifiers;

/**
 * Handles the bot's armour/tool loadout, inventory hand-over and food consumption.
 */
public final class EquipmentManager {
	private static final EquipmentSlot[] ARMOR_SLOTS = {
			EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

	private EquipmentManager() {
	}

	/** Give the bot a full starter kit of iron armour, a sword and a shield. */
	public static void equipStarterKit(HeroBotEntity bot) {
		bot.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));
		bot.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
		bot.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.IRON_LEGGINGS));
		bot.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.IRON_BOOTS));
		bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
		bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
	}

	// ---- scoring ----

	private static double attributeScore(ItemStack stack, Holder<Attribute> attribute) {
		if (stack.isEmpty()) {
			return 0.0D;
		}
		ItemAttributeModifiers mods = stack.getOrDefault(DataComponents.ATTRIBUTE_MODIFIERS, ItemAttributeModifiers.EMPTY);
		double total = 0.0D;
		for (ItemAttributeModifiers.Entry entry : mods.modifiers()) {
			if (entry.attribute().is(attribute)) {
				total += entry.modifier().amount();
			}
		}
		return total;
	}

	private static boolean isMeleeWeapon(ItemStack stack) {
		return stack.is(ItemTags.SWORDS) || stack.is(ItemTags.AXES);
	}

	// ---- inventory hand-over ----

	/**
	 * Stores an item handed to the bot. Better armour / weapons are worn immediately and the old
	 * piece goes to the inventory. Returns whatever could not be accepted.
	 */
	public static ItemStack acceptItem(HeroBotEntity bot, ItemStack stack) {
		ItemStack rest = bot.getInventory().addItem(stack);
		equipBest(bot);
		return rest;
	}

	/** Upgrades armour, main-hand weapon and off-hand shield from the inventory. */
	public static void equipBest(HeroBotEntity bot) {
		SimpleContainer inv = bot.getInventory();
		for (EquipmentSlot slot : ARMOR_SLOTS) {
			int bestIdx = -1;
			double bestScore = attributeScore(bot.getItemBySlot(slot), Attributes.ARMOR);
			for (int i = 0; i < inv.getContainerSize(); i++) {
				ItemStack s = inv.getItem(i);
				if (!s.isEmpty() && bot.getEquipmentSlotForItem(s) == slot) {
					double score = attributeScore(s, Attributes.ARMOR);
					if (score > bestScore) {
						bestScore = score;
						bestIdx = i;
					}
				}
			}
			if (bestIdx >= 0) {
				swapWithInventory(bot, inv, bestIdx, slot);
			}
		}

		int weaponIdx = -1;
		double weaponScore = isMeleeWeapon(bot.getMainHandItem())
				? attributeScore(bot.getMainHandItem(), Attributes.ATTACK_DAMAGE) : -1.0D;
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack s = inv.getItem(i);
			if (isMeleeWeapon(s)) {
				double score = attributeScore(s, Attributes.ATTACK_DAMAGE);
				if (score > weaponScore) {
					weaponScore = score;
					weaponIdx = i;
				}
			}
		}
		if (weaponIdx >= 0) {
			swapWithInventory(bot, inv, weaponIdx, EquipmentSlot.MAINHAND);
		}

		if (bot.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty()) {
			for (int i = 0; i < inv.getContainerSize(); i++) {
				if (inv.getItem(i).is(Items.SHIELD)) {
					swapWithInventory(bot, inv, i, EquipmentSlot.OFFHAND);
					break;
				}
			}
		}
	}

	private static void swapWithInventory(HeroBotEntity bot, SimpleContainer inv, int index, EquipmentSlot slot) {
		ItemStack incoming = inv.getItem(index);
		ItemStack old = bot.getItemBySlot(slot);
		bot.setItemSlot(slot, incoming.copyWithCount(1));
		incoming.shrink(1);
		if (incoming.isEmpty()) {
			inv.setItem(index, ItemStack.EMPTY);
		}
		if (!old.isEmpty()) {
			ItemStack leftover = inv.addItem(old);
			if (!leftover.isEmpty()) {
				bot.spawnAtLocation((net.minecraft.server.level.ServerLevel) bot.level(), leftover);
			}
		}
	}

	// ---- food ----

	/** Eats one food item from the inventory (or the main hand) to heal. True if something was eaten. */
	public static boolean tryEatFood(HeroBotEntity bot) {
		if (bot.getHealth() >= bot.getMaxHealth()) {
			return false;
		}
		SimpleContainer inv = bot.getInventory();
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack s = inv.getItem(i);
			FoodProperties food = s.get(DataComponents.FOOD);
			if (food != null) {
				bot.heal(Math.max(2.0F, food.nutrition()));
				s.shrink(1);
				if (s.isEmpty()) {
					inv.setItem(i, ItemStack.EMPTY);
				}
				return true;
			}
		}
		ItemStack main = bot.getMainHandItem();
		FoodProperties food = main.get(DataComponents.FOOD);
		if (food != null) {
			bot.heal(Math.max(2.0F, food.nutrition()));
			main.shrink(1);
			return true;
		}
		return false;
	}
}

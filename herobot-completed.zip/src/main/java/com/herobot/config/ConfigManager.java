package com.herobot.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.herobot.HeroBot;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Loads and persists the {@link HeroBotConfig}. The config lives in the standard Fabric config
 * directory and is created with defaults on first launch.
 */
public final class ConfigManager {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static HeroBotConfig config = new HeroBotConfig();

	private ConfigManager() {
	}

	private static Path configPath() {
		return FabricLoader.getInstance().getConfigDir().resolve("herobot.json");
	}

	public static HeroBotConfig get() {
		return config;
	}

	public static void load() {
		Path path = configPath();
		try {
			if (Files.exists(path)) {
				String json = Files.readString(path);
				HeroBotConfig loaded = GSON.fromJson(json, HeroBotConfig.class);
				if (loaded != null) {
					config = loaded;
				}
				HeroBot.LOGGER.info("[HeroBot] Loaded config from {}", path);
			} else {
				save();
				HeroBot.LOGGER.info("[HeroBot] Wrote default config to {}", path);
			}
		} catch (Exception e) {
			HeroBot.LOGGER.error("[HeroBot] Failed to load config, using defaults", e);
			config = new HeroBotConfig();
		}
	}

	public static void save() {
		Path path = configPath();
		try {
			Files.createDirectories(path.getParent());
			Files.writeString(path, GSON.toJson(config));
		} catch (IOException e) {
			HeroBot.LOGGER.error("[HeroBot] Failed to save config", e);
		}
	}
}

package com.herobot.combat;

import com.herobot.entity.HeroBotEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Target selection, weapon/shield handling and ranged attacks for the HeroBot.
 */
public final class CombatManager {
	private CombatManager() {
	}

	/**
	 * Makes sure the bot is holding a usable weapon in its main hand. If it has nothing it is handed
	 * an iron sword so it can always defend its owner.
	 */
	public static void selectEquipment(HeroBotEntity bot) {
		ItemStack main = bot.getMainHandItem();
		if (main.isEmpty()) {
			bot.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
		}
		// Keep a shield in the off-hand for blocking if the slot is empty.
		if (bot.getItemBySlot(EquipmentSlot.OFFHAND).isEmpty()) {
			bot.setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
		}
	}

	/**
	 * Simple, robust ranged attack: deals arrow-equivalent damage to the target when the bot is
	 * holding a bow/crossbow. Avoids spawning projectile entities so it behaves deterministically.
	 */
	public static void performRangedAttack(HeroBotEntity bot, LivingEntity target, float power) {
		if (!(bot.level() instanceof ServerLevel server)) {
			return;
		}
		float damage = 4.0F + power * 2.0F;
		target.hurtServer(server, bot.damageSources().mobAttack(bot), damage);
		bot.swing(InteractionHand.MAIN_HAND);
	}
}

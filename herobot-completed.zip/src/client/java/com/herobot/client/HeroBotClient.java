package com.herobot.client;

import com.herobot.HeroBot;
import com.herobot.entity.HeroBotEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

/**
 * Client entrypoint: registers the player-like renderer for the HeroBot entity.
 */
public class HeroBotClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(HeroBotEntities.HEROBOT, HeroBotRenderer::new);
		HeroBot.LOGGER.info("[HeroBot] Client renderer registered");
	}
}
